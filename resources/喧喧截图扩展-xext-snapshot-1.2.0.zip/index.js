const path = require('path');
const {execFile} = require('child_process');

const {platform} = global.Xext;
const {clipboard, ui, image, screenshot} = platform.$module || platform;
const NOT_SUPPORT_OS = platform.env.os !== 'windows';
const MAX_BASE64_IMAGE_SIZE = 1024 * 10;
let backupCaptureAndCutScreenImage = null;

const takeScreenShot = () => {
    return new Promise((resolve, reject) => {
        const oldImageFromClipboard = clipboard.readImage('image/png');
        const oldImageBase64 = oldImageFromClipboard.toDataURL();
        execFile(path.join(__dirname, 'bin/SnapShot.exe'), [], (error, stdout, stderr) => {
            if (error) {
                return reject(error);
            }
            const screenImageFromClipboard = clipboard.readImage('image/png');
            if (screenImageFromClipboard && !screenImageFromClipboard.isEmpty()) {
                const base64 = screenImageFromClipboard.toDataURL();
                if (oldImageBase64 === base64) {
                    return reject(error);
                }
                const imageBuffer = screenImageFromClipboard.toPNG();
                const filePath = ui.makeTmpFilePath('.png');
                image.saveImage(imageBuffer, filePath).then(savedImage => {
                    savedImage.size = imageBuffer.length;
                    if (imageBuffer.length < MAX_BASE64_IMAGE_SIZE) {
                        savedImage.base64 = base64;
                    } else {
                        savedImage.blob = new Blob([new Uint8Array(imageBuffer)]);
                    }
                    resolve(savedImage);
                }).catch(reject);
            } else {
                reject(error);
            }
        });
    });
};

const captureAndCutScreenImage = (_, hideCurrentWindow = false) => {
    hideCurrentWindow = hideCurrentWindow && ui.browserWindow.isVisible();
    if (hideCurrentWindow) {
        ui.browserWindow.hide();
    }
    return takeScreenShot().then(image => {
        if (hideCurrentWindow) {
            ui.browserWindow.show();
            ui.browserWindow.focus();
        }
        return Promise.resolve(image);
    });
};

module.exports = {
    onAttach: ext => {
        if (NOT_SUPPORT_OS) {
            return;
        }
        backupCaptureAndCutScreenImage = screenshot.captureAndCutScreenImage;
        screenshot.captureAndCutScreenImage = captureAndCutScreenImage;
    },
    onDetach: ext => {
        if (NOT_SUPPORT_OS) {
            return;
        }
        if (backupCaptureAndCutScreenImage) {
            screenshot.captureAndCutScreenImage = backupCaptureAndCutScreenImage;
            backupCaptureAndCutScreenImage = null;
        }
    },
};
